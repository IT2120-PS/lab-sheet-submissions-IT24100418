
setwd("C:/Users/PASINDU VIHANGA/Desktop/IT24100418")

#01
n <- 50
p <- 0.85

#(i) Distribution: Binomial(50, 0.85)

#(ii) P(X >= 47) = 1 - P(X <= 46)
1 - pbinom(46, size=n, prob=p)

#02
lambda <- 12

#(i) X = number of calls per hour

#(ii) Distribution: Poisson(12)

# (iii) P(X = 15)
dpois(15, lambda=lambda)
