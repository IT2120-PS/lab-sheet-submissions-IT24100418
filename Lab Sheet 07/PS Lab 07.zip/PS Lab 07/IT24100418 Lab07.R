
setwd("C:/Users/PASINDU VIHANGA/Desktop/PS Lab 07")

#1
punif(25, min=0, max=40) - punif(10, min=0, max=40)

#2
lambda2 <- 1/3
pexp(2, rate=lambda2)

#3
1 - pnorm(130, mean=100, sd=15)
qnorm(0.95, mean=100, sd=15)
