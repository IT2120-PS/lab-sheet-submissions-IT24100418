setwd("C:\\Users\\PASINDU VIHANGA\\Desktop\\SLIIT\\Year 02\\Semester 01\\P&S\\Week 06\\Lab 05-20250828")

#Question01
Delivery_Times<-read.table("Exercise - Lab 05.txt",header = TRUE)
Delivery_Times

#Question02
histogram<-hist(Delivery_Times$Delivery,main="Histogram for Delivery Times",ylab = "Frequency",xlab = "Delivery Times",breaks = seq(20, 70,length=10),right = FALSE)

#Question03
This is a Right-skewed distribution

#Question04
breaks <- histogram$breaks
freq <- histogram$counts
mids <- histogram$mids

classes<-c()

for(i in 1:length(breaks)-1){
  classes[i]<- paste0("[",breaks[i],",",breaks[i+1],")")
  cbind(Classes=classes, frequency= freq)
}

cbind(Classes=classes, frequency= freq)

cum.freq<-cumsum(freq)

new<-c(0,cum.freq)

plot(breaks, new, type = 'o', main="Cumalative Frequency Polygon (Ogive)", xlab = "Delivery Time", ylab = "Cumulative Frequency")
cbind(Upper = breaks, CumFreq = new)
